__app_name__ = "shape-color-vision"
__version__ = "0.1.0"
