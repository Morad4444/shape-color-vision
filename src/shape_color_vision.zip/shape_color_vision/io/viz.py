"""
viz.py — Visualization utilities for the Shape-Color Vision pipeline.

Responsibilities:
• Display processed frames, segmentation masks, and annotated outputs.
• Provide helper functions for drawing shapes, contours, labels, and colors.
• Keep visualization logic separate from detection and preprocessing logic.
• Serve as an optional UI layer that can be replaced/extended without
  modifying core detection code (supports Open/Closed Principle).

This module does NOT:
• Perform any detection or color/shape analysis.
• Load input images or handle file I/O (Single Responsibility).
"""


import cv2
import numpy as np
from typing import Tuple

def draw_label(img, text: str, org: Tuple[int, int]):
    cv2.putText(img, text, org, cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 3, cv2.LINE_AA)
    cv2.putText(img, text, org, cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1, cv2.LINE_AA)

def draw_contour(img, contour: np.ndarray):
    cv2.drawContours(img, [contour], -1, (0, 255, 0), 2)
